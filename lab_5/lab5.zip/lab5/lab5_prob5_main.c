void print_hello();
int main(int argc, char *argv[]) {
    print_hello();
    return 0; 
}