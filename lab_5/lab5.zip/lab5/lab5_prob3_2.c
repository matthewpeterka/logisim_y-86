#include <stdio.h>
int main(int argc, char *argv[]) {
    int i = 1;
    i++;
    printf("The value of i is %d\n", i); 
    return 0;
}